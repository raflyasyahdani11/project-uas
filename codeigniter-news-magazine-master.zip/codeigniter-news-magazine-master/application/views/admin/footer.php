			<div class="clear"></div> <!-- End .clear -->

			<div id="footer">
				<small> <!-- Remove this notice or replace it with whatever you want -->
						&#169; Copyright 2019 Priceless News " Stich Team " | Powered by <a target="_blank" href="https://www.facebook.com/yousseifweroquia">Priceless News</a> 
				</small>
			</div><!-- End #footer -->
			
		</div> <!-- End #main-content -->
		
	</div></body>
  


</html>