<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Facebook extends CI_Controller {

	private $fb;

	public function __construct()
	{
		parent::__construct();
		$this->load->library("facebooksdk");
		$this->fb = $this->facebooksdk;
	}

	public function login()
	{
		$cb = "http://localhost/codeigniter-news-magazine-master/index.php/facebook/callback";
		$url = $this->fb->getLoginUrl($cb);
		redirect($url);
	}

	public function callback()
	{
		
     	redirect('admin');
	
	}
	
	

	
}